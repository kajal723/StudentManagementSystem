package gui;

import model.Student;
import dao.StudentDAOImpl;

import javax.swing.*;
import java.awt.*;

public class StudentGUI extends JFrame {
    private JTextField tName, tAge, tCourse, tEmail;
    private JButton addBtn;

    public StudentGUI() {
        setTitle("Student Management - GUI");
        setSize(400,250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5,2,5,5));

        add(new JLabel("Name:"));
        tName = new JTextField();
        add(tName);

        add(new JLabel("Age:"));
        tAge = new JTextField();
        add(tAge);

        add(new JLabel("Course:"));
        tCourse = new JTextField();
        add(tCourse);

        add(new JLabel("Email:"));
        tEmail = new JTextField();
        add(tEmail);

        addBtn = new JButton("Add Student");
        add(addBtn);

        addBtn.addActionListener(e -> {
            try {
                Student s = new Student(
                    tName.getText(),
                    Integer.parseInt(tAge.getText()),
                    tCourse.getText(),
                    tEmail.getText()
                );
                boolean ok = new StudentDAOImpl().addStudent(s);
                JOptionPane.showMessageDialog(this, ok ? "Student added" : "Add failed");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentGUI g = new StudentGUI();
            g.setVisible(true);
        });
    }
}
