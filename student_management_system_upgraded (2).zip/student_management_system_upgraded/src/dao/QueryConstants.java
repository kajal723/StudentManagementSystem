package dao;

public class QueryConstants {
    // Insert without id so the database can assign an AUTO_INCREMENT primary key
    public static final String INSERT_STUDENT = "INSERT INTO students(name, age, email, course, fees) VALUES (?, ?, ?, ?, ?)";
    public static final String SELECT_ALL = "SELECT id, name, age, email, course, fees FROM students";
    public static final String SELECT_BY_ID = "SELECT id, name, age, email, course, fees FROM students WHERE id = ?";
    public static final String UPDATE_STUDENT = "UPDATE students SET name=?, age=?, email=?, course=?, fees=? WHERE id=?";
    public static final String DELETE_STUDENT = "DELETE FROM students WHERE id=?";
}
