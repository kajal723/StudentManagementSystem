package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import util.DBConnection;

public abstract class BaseDAO {
    protected Connection getConnection() {
        return DBConnection.getConnection();
    }

    protected void closeResources(Connection c, PreparedStatement p, ResultSet r) {
        DBConnection.closeResources(c, p, r);
    }

    protected void closeResources(Connection c, PreparedStatement p) {
        DBConnection.closeResources(c, p, null);
    }
}


