package dao;

import model.Student;
import exceptions.DatabaseException;
import exceptions.StudentNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl extends BaseDAO implements StudentDAO {

    @Override
    public void addStudent(Student s) {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(QueryConstants.INSERT_STUDENT, Statement.RETURN_GENERATED_KEYS)) {
            // INSERT now omits id; set parameters name, age, email, course, fees
            ps.setString(1, s.getName());
            ps.setInt(2, s.getAge());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getCourse());
            ps.setDouble(5, s.getFees());
            int rows = ps.executeUpdate();
            if (rows == 0) throw new SQLException("Inserting student failed, no rows affected");
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    s.setId(keys.getInt(1));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error adding student", e);
        }
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(QueryConstants.SELECT_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Student s = new Student(rs.getInt("id"), rs.getString("name"), rs.getInt("age"),
                        rs.getString("email"), rs.getString("course"), rs.getDouble("fees"));
                list.add(s);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error fetching students", e);
        }
        return list;
    }

    @Override
    public Student getStudentById(int id) {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(QueryConstants.SELECT_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Student(rs.getInt("id"), rs.getString("name"), rs.getInt("age"),
                            rs.getString("email"), rs.getString("course"), rs.getDouble("fees"));
                } else {
                    return null;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error fetching student by id", e);
        }
    }

    @Override
    public void updateStudent(Student s) {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(QueryConstants.UPDATE_STUDENT)) {
            ps.setString(1, s.getName());
            ps.setInt(2, s.getAge());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getCourse());
            ps.setDouble(5, s.getFees());
            ps.setInt(6, s.getId());
            int rows = ps.executeUpdate();
            if (rows == 0) throw new StudentNotFoundException("No student to update with id " + s.getId());
        } catch (SQLException e) {
            throw new DatabaseException("Error updating student", e);
        }
    }

    @Override
    public void deleteStudent(int id) {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(QueryConstants.DELETE_STUDENT)) {
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            if (rows == 0) throw new StudentNotFoundException("No student to delete with id " + id);
        } catch (SQLException e) {
            throw new DatabaseException("Error deleting student", e);
        }
    }
}
