package validation;

import exceptions.InvalidStudentException;

public interface Validatable {
    void validate() throws InvalidStudentException;
}
