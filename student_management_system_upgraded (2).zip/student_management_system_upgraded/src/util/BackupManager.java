package util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.Student;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Collection;

public final class BackupManager {
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private static final Path DEFAULT_FILE = Path.of("backup_students.json");

    private BackupManager() {}

    public static void backup(Collection<? extends Student> students) throws IOException {
        backupTo(students, DEFAULT_FILE);
    }

    public static void backupTo(Collection<? extends Student> students, Path file) throws IOException {
        try (FileWriter fw = new FileWriter(file.toFile(), false)) {
            fw.write(gson.toJson(students));
        }
    }
}
