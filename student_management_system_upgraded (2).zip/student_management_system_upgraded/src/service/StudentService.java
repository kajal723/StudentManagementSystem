package service;

import dao.StudentDAO;
import dao.StudentDAOImpl;
import model.Student;
import exceptions.InvalidStudentException;

import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class StudentService {
    private final StudentDAO dao = new StudentDAOImpl();
    private final StudentRegistry<Student> registry = new StudentRegistry<>();
    private final ExecutorService background = Executors.newFixedThreadPool(2);
    // Background executor used for DB loads and background backups

    public StudentRegistry<Student> getRegistry() {
        return registry;
    }

    public synchronized void registerStudent(Student s) {
        s.validate();
        dao.addStudent(s);
        registry.addIfAbsent(s);
    }

    /**
     * Register and schedule a background backup after successful registration.
     */
    public synchronized void registerStudentWithBackup(Student s) {
        registerStudent(s);
        background.submit(() -> {
            try {
                util.BackupManager.backup(registry.getAll());
            } catch (Exception e) {
                System.err.println("Background backup after register failed: " + e.getMessage());
            }
        });
    }

    public Student getStudent(int id) {
        Student s = registry.findById(id);
        if (s != null) return s;
        s = dao.getStudentById(id);
        if (s != null) registry.addIfAbsent(s);
        return s;
    }

    public synchronized void updateStudent(Student s) {
        s.validate();
        dao.updateStudent(s);
        registry.removeById(s.getId());
        registry.addIfAbsent(s);
    }

    public synchronized void updateStudentWithBackup(Student s) {
        updateStudent(s);
        background.submit(() -> {
            try { util.BackupManager.backup(registry.getAll()); } catch (Exception e) { System.err.println("Background backup after update failed: " + e.getMessage()); }
        });
    }

    public synchronized boolean deleteStudent(int id) {
        try {
            dao.deleteStudent(id);
        } catch (RuntimeException ex) {
            return false;
        }
        return registry.removeById(id);
    }

    public synchronized boolean deleteStudentWithBackup(int id) {
        boolean ok = deleteStudent(id);
        if (ok) {
            background.submit(() -> {
                try { util.BackupManager.backup(registry.getAll()); } catch (Exception e) { System.err.println("Background backup after delete failed: " + e.getMessage()); }
            });
        }
        return ok;
    }

    public List<Student> listAll() {
        return registry.getAll();
    }

    /**
     * Load all students from DB into registry asynchronously and return a Future
     * so callers can optionally wait for completion.
     */
    public Future<?> loadAllFromDb() {
        return background.submit(() -> {
            try {
                List<Student> fromDb = dao.getAllStudents();
                registry.clearAndAddAll(fromDb);
            } catch (Exception e) {
                System.err.println("Failed to load students from DB: " + e.getMessage());
            }
        });
    }

    public void sortById() {
        registry.sort(Comparator.comparingInt(Student::getId));
    }

    public void shutdown() {
        background.shutdownNow();
    }
}
