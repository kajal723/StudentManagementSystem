package service;

import model.Student;

import java.util.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class StudentRegistry<T extends Student> {
    private final List<T> students = new ArrayList<>();
    private final Map<Integer, T> index = new HashMap<>();
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    public void add(T s) {
        lock.writeLock().lock();
        try {
            students.add(s);
            index.put(s.getId(), s);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void addIfAbsent(T s) {
        lock.writeLock().lock();
        try {
            if (!index.containsKey(s.getId())) {
                students.add(s);
                index.put(s.getId(), s);
            }
        } finally {
            lock.writeLock().unlock();
        }
    }

    public T findById(int id) {
        lock.readLock().lock();
        try {
            return index.get(id);
        } finally {
            lock.readLock().unlock();
        }
    }

    public boolean removeById(int id) {
        lock.writeLock().lock();
        try {
            T removed = index.remove(id);
            if (removed != null) {
                students.remove(removed);
                return true;
            }
            return false;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public List<T> getAll() {
        lock.readLock().lock();
        try {
            return new ArrayList<>(students);
        } finally {
            lock.readLock().unlock();
        }
    }

    public void sort(Comparator<T> cmp) {
        lock.writeLock().lock();
        try {
            students.sort(cmp);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void clearAndAddAll(Collection<T> coll) {
        lock.writeLock().lock();
        try {
            students.clear();
            index.clear();
            for (T s : coll) {
                students.add(s);
                index.put(s.getId(), s);
            }
        } finally {
            lock.writeLock().unlock();
        }
    }
}
