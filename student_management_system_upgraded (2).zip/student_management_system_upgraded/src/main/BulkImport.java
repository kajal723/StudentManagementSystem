package main;

import service.StudentService;
import model.Student;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * CSV bulk importer.
 * Expected CSV format (header optional):
 * name,age,course,email,fees
 *
 * This importer now:
 * - detects and skips header lines reliably
 * - parses numeric fields and validates rows
 * - uses StudentService.registerStudentWithBackup so the in-memory registry
 *   is updated and a background backup is scheduled after each insert
 */
public class BulkImport {
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.out.println("Usage: java main.BulkImport <path-to-csv>");
            return;
        }
        Path p = Path.of(args[0]);
        if (!p.toFile().exists()) {
            System.err.println("File not found: " + p);
            return;
        }

        List<String[]> rows = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(p.toFile()))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] tokens = splitCsvLine(line);
                if (first) {
                    first = false;
                    if (looksLikeHeader(tokens)) {
                        // skip header
                        continue;
                    }
                }
                rows.add(tokens);
            }
        }

        StudentService service = new StudentService();
        int success = 0;
        for (String[] parts : rows) {
            // parse and validate
            String name = parts.length > 0 ? parts[0].trim() : "";
            Integer age = null;
            if (parts.length > 1) {
                String araw = parts[1].trim();
                try { age = Integer.parseInt(araw); } catch (Exception ex) {
                    // try to extract digits if malformed (e.g., invisible chars)
                    String digits = araw.replaceAll("[^0-9-]", "");
                    if (!digits.isEmpty()) try { age = Integer.parseInt(digits); } catch (Exception ignored) {}
                }
            }
            String course = parts.length > 2 ? parts[2].trim() : "";
            String email = parts.length > 3 ? parts[3].trim() : "";
            Double fees = null;
            if (parts.length > 4) {
                String fraw = parts[4].trim();
                try { fees = Double.parseDouble(fraw); } catch (Exception ex) {
                    String num = fraw.replaceAll("[^0-9.-]", "");
                    if (!num.isEmpty()) try { fees = Double.parseDouble(num); } catch (Exception ignored) {}
                }
            }

            // Basic validation
            boolean valid = true;
            if (name.isBlank()) { System.err.println("Skipping row: name empty"); valid = false; }
            if (age == null || age <= 0) { System.err.println("Skipping row: invalid age for " + name); valid = false; }
            if (email.isBlank() || !email.contains("@")) { System.err.println("Skipping row: invalid email for " + name); valid = false; }

            if (!valid) continue;

            Student s = new Student(name, age, course, email);
            if (fees != null) s.setFees(fees);

            try {
                service.registerStudentWithBackup(s);
                success++;
                System.out.println("Inserted: " + s.getName() + " (id=" + s.getId() + ")");
            } catch (Exception e) {
                System.err.println("Failed to insert " + s.getName() + ": " + e.getMessage());
            }
        }

        System.out.println("Imported " + success + " of " + rows.size() + " rows.");

        // Ensure backup is written immediately with the latest registry contents
        try {
            util.BackupManager.backup(service.getRegistry().getAll());
        } catch (Exception e) {
            System.err.println("Failed to write final backup: " + e.getMessage());
        }
    }

    private static boolean looksLikeHeader(String[] tokens) {
        if (tokens.length == 0) return false;
        String t0 = tokens[0].trim().toLowerCase();
        if (t0.equals("name") || t0.equals("full name") || t0.contains("name")) return true;
        return false;
    }

    private static String[] splitCsvLine(String line) {
        // simple CSV parser that supports quoted fields with commas
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    // escaped quote
                    cur.append('"');
                    i++; // skip next
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (c == ',' && !inQuotes) {
                out.add(cur.toString()); cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        out.add(cur.toString());
        return out.toArray(new String[0]);
    }
}
