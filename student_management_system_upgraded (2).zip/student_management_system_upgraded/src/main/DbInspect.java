package main;

import dao.StudentDAOImpl;
import model.Student;

import java.util.List;

public class DbInspect {
    public static void main(String[] args) {
        try {
            StudentDAOImpl dao = new StudentDAOImpl();
            List<Student> rows = dao.getAllStudents();
            System.out.println("DB rows count: " + rows.size());
            for (Student s : rows) System.out.println(s);
        } catch (Exception e) {
            System.err.println("Failed to inspect DB: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("\n-- backup_students.json contents --");
        try {
            String json = java.nio.file.Files.readString(java.nio.file.Path.of("backup_students.json"));
            System.out.println(json);
        } catch (Exception e) {
            System.out.println("backup_students.json not found or unreadable: " + e.getMessage());
        }
    }
}
