package main;

import model.Student;
import service.StudentService;
import threads.AutoBackupThread;

import java.util.List;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        StudentService service = new StudentService();

        // load DB records into memory (async) and wait briefly for completion
        java.util.concurrent.Future<?> loadFuture = service.loadAllFromDb();
        try {
            loadFuture.get(5, java.util.concurrent.TimeUnit.SECONDS);
        } catch (Exception e) {
            System.err.println("Warning: loadAllFromDb didn't finish before backup: " + e.getMessage());
        }

        // start backup thread using registry from service
        AutoBackupThread backup = new AutoBackupThread(service.getRegistry());
        backup.start();

        Scanner sc = new Scanner(System.in);

        while (true) {
            printMenu();
            int choice = readInt(sc, "Enter choice: ");

            switch (choice) {
                case 1 -> addStudent(sc, service);
                case 2 -> viewStudent(sc, service);
                case 3 -> updateStudent(sc, service);
                case 4 -> deleteStudent(sc, service);
                case 5 -> listAll(service);
                case 6 -> exportCsv(service);
                case 7 -> {
                    System.out.println("Shutting down background services...");
                    backup.stop(); service.shutdown();
                    System.out.println("Goodbye!"); return;
                }
                default -> System.out.println("Invalid option");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n=== STUDENT MANAGEMENT SYSTEM ===");
        System.out.println("1. Add Student");
        System.out.println("2. View Student by ID");
        System.out.println("3. Update Student");
        System.out.println("4. Delete Student");
        System.out.println("5. List All Students");
        System.out.println("6. Export to CSV");
        System.out.println("7. Exit");
    }

    private static int readInt(Scanner sc, String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }

    private static void addStudent(Scanner sc, StudentService service) {
        System.out.print("Name: "); String name = sc.nextLine();
        int age = readInt(sc, "Age: ");
        System.out.print("Course: "); String course = sc.nextLine();
        System.out.print("Email: "); String email = sc.nextLine();
        double fees = 0.0;
        try { System.out.print("Fees: "); fees = Double.parseDouble(sc.nextLine().trim()); } catch (Exception ignored) {}
        Student s = new Student(name, age, course, email);
        s.setFees(fees);
        try {
            service.registerStudent(s);
            System.out.println("Student registered.");
        } catch (Exception e) { System.out.println("Failed: " + e.getMessage()); }
    }

    private static void viewStudent(Scanner sc, StudentService service) {
        int id = readInt(sc, "Enter ID: ");
        Student s = service.getStudent(id);
        if (s == null) System.out.println("Not found"); else System.out.println(s);
    }

    private static void updateStudent(Scanner sc, StudentService service) {
        int id = readInt(sc, "Enter ID to update: ");
        Student s = service.getStudent(id);
        if (s == null) { System.out.println("Not found"); return; }
        System.out.print("New name (blank to keep): "); String name = sc.nextLine(); if (!name.isBlank()) s.setName(name);
        System.out.print("New age (blank to keep): "); String ageStr = sc.nextLine(); if (!ageStr.isBlank()) s.setAge(Integer.parseInt(ageStr));
        System.out.print("New course (blank to keep): "); String course = sc.nextLine(); if (!course.isBlank()) s.setCourse(course);
        System.out.print("New email (blank to keep): "); String email = sc.nextLine(); if (!email.isBlank()) s.setEmail(email);
        System.out.print("New fees (blank to keep): "); String feesStr = sc.nextLine(); if (!feesStr.isBlank()) s.setFees(Double.parseDouble(feesStr));
        try { service.updateStudent(s); System.out.println("Updated"); } catch (Exception e) { System.out.println("Failed: " + e.getMessage()); }
    }

    private static void deleteStudent(Scanner sc, StudentService service) {
        int id = readInt(sc, "Enter ID to delete: ");
        boolean ok = service.deleteStudent(id);
        System.out.println(ok ? "Deleted" : "Not found");
    }

    private static void listAll(StudentService service) {
        List<Student> list = service.listAll();
        if (list.isEmpty()) { System.out.println("No students"); return; }
        list.forEach(System.out::println);
    }

    private static void exportCsv(StudentService service) {
        List<Student> list = service.listAll();
        StringBuilder sb = new StringBuilder();
        sb.append("id,name,age,email,course,fees\n");
        for (Student s : list) {
            sb.append(String.format("%d,%s,%d,%s,%s,%.2f\n", s.getId(), s.getName(), s.getAge(), s.getEmail(), s.getCourse(), s.getFees()));
        }
        try { java.nio.file.Files.write(java.nio.file.Paths.get("students_export.csv"), sb.toString().getBytes()); System.out.println("Exported to students_export.csv"); }
        catch (Exception e) { System.out.println("Export failed: " + e.getMessage()); }
    }
}
