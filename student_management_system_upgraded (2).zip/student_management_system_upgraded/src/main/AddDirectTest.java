package main;

import model.Student;
import dao.StudentDAOImpl;

public class AddDirectTest {
    public static void main(String[] args) {
        Student s = new Student("CLI Test", 22, "CS", "cli.test@example.com");
        try {
            new StudentDAOImpl().addStudent(s);
            System.out.println("Add succeeded");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
