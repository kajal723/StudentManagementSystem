package main;

import util.DBConnection;

import java.sql.Connection;
import java.sql.Statement;

public class DbMigrate {
    public static void main(String[] args) {
        try (Connection con = DBConnection.getConnection(); Statement st = con.createStatement()) {
            try {
                st.executeUpdate("ALTER TABLE students ADD COLUMN fees DOUBLE DEFAULT 0.0");
                System.out.println("Migration: added 'fees' column.");
            } catch (Exception e) {
                System.out.println("Migration: fees column may already exist or migration failed: " + e.getMessage());
            }
        } catch (Exception e) {
            System.err.println("Migration failed to connect: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
