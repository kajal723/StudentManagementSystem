package model;

public class RegularStudent extends Student {
    public RegularStudent(int id, String name, int age, String email, String course, double fees) {
        super(id, name, age, email, course, fees);
    }

    @Override
    public double calculateFees() {
        return getFees();
    }
}

