package model;

import exceptions.InvalidStudentException;
import validation.Validatable;

public class Student extends Person implements Validatable {
    private String course;
    private double fees;

    public Student() {}

    // Constructor used by the CLI App (no id)
    public Student(String name, int age, String course, String email) {
        super(0, name, age, email);
        this.course = course;
        this.fees = 0.0;
    }

    // Full constructor (id + fees)
    public Student(int id, String name, int age, String email, String course, double fees) {
        super(id, name, age, email);
        this.course = course;
        this.fees = fees;
    }

    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    public double getFees() { return fees; }
    public void setFees(double fees) { this.fees = fees; }

    @Override
    public double calculateFees() {
        return fees;
    }

    @Override
    public void validate() throws InvalidStudentException {
        if (name == null || name.trim().isEmpty()) throw new InvalidStudentException("Name cannot be empty");
        if (age <= 0) throw new InvalidStudentException("Invalid age");
        if (email == null || !email.contains("@")) throw new InvalidStudentException("Invalid email");
    }

    @Override
    public String toString() {
        return String.format("Student[id=%d, name=%s, age=%d, course=%s, email=%s, fees=%.2f]",
                id, name, age, course, email, fees);
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Student)) return false;
        Student s = (Student) o; return this.id == s.id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}
