package model;

public class ScholarshipStudent extends Student {
    private double scholarshipPercent;

    public ScholarshipStudent(int id, String name, int age, String email, String course, double fees, double scholarshipPercent) {
        super(id, name, age, email, course, fees);
        this.scholarshipPercent = scholarshipPercent;
    }

    @Override
    public double calculateFees() {
        return getFees() * (1 - scholarshipPercent / 100.0);
    }

    public double getScholarshipPercent() { return scholarshipPercent; }
    public void setScholarshipPercent(double p) { this.scholarshipPercent = p; }
}
