package threads;

import service.StudentRegistry;
import model.Student;

import java.io.IOException;
import java.nio.file.Path;
import java.util.concurrent.*;

public class AutoBackupThread implements Runnable {
    private final StudentRegistry<Student> registry;
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final String backupFile = "backup_students.json";
    private final long initialDelaySeconds;

    public AutoBackupThread(StudentRegistry<Student> registry) {
        this(registry, 1); // default initial delay 1s
    }

    public AutoBackupThread(StudentRegistry<Student> registry, long initialDelaySeconds) {
        this.registry = registry;
        this.initialDelaySeconds = initialDelaySeconds;
    }

    public void start() {
        // start using configurable initial delay so quick runs can capture data
        scheduler.scheduleAtFixedRate(this, initialDelaySeconds, 30, TimeUnit.SECONDS); // every 30s
    }

    public void stop() {
        scheduler.shutdownNow();
    }

    @Override
    public void run() {
        try {
            var students = registry.getAll();
            util.BackupManager.backupTo(students, Path.of(backupFile));
            System.out.println("AutoBackup: backed up " + students.size() + " students to " + backupFile + " at " + java.time.Instant.now());
        } catch (IOException ioe) {
            System.err.println("AutoBackup failed writing backup: " + ioe.getMessage());
        }
    }

    /**
     * Trigger a manual backup immediately (runs in calling thread).
     */
    public void backupNow() {
        try {
            util.BackupManager.backup(registry.getAll());
        } catch (IOException e) {
            System.err.println("Manual backup failed: " + e.getMessage());
        }
    }
}
