Project: Student Management System — Mavenized

Quick overview
- This adds a `pom.xml` so dependencies (Gson, MySQL Connector, servlet API) are managed by Maven.
- Adds a `BackupManager` utility for writing JSON backups.
- `AutoBackupThread` now supports configurable initial delay and uses `BackupManager`.
- `StudentService` gained `*WithBackup` methods which schedule immediate background backups after data changes.

Build (locally)
1. Install Maven (if not already). On Windows: download from https://maven.apache.org/download.cgi and add `bin` to PATH.
2. From project root run:
```powershell
mvn clean package
```
This produces a shaded jar in `target/` named like `student-management-system-1.0.0.jar` (executable, main class `main.App`).

Run
```powershell
# after building
java -jar target/student-management-system-1.0.0.jar
```

If you don't want to use Maven, the `out` directory approach (manual `javac` / `java` commands) still works — see previous instructions in the repo.

Notes
- The `backup_students.json` file will be created in the process working directory.
- To import many students, use `main.BulkImport`:
```powershell
java -cp target/student-management-system-1.0.0.jar main.BulkImport path\to\students.csv
```