# Student Management System - Java

This is a complete Java Student Management System project including:
- Core Java (OOP, Collections, Exception Handling)
- JDBC (MySQL) DAO implementation
- Service layer
- Simple Swing GUI
- Servlet example for Web version
- SQL file to create database

## Structure
- src/ - Java source files (packages under folders)
- web/ - servlet + web.xml
- sql/ - database creation script
- build_instructions.txt - how to compile and run

## Notes
- Update DBConnection credentials in `src/util/DBConnection.java`.
- Requires Java 8+ and MySQL server (or change DB URL for other DB).
